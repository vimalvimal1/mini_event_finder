

 
class DiscountProcessor():
    def process(self, cart_items):
        total_discount=0
        for item in cart_items:
            total_discount+=(item.product.product_discount*item.product_count)
        return total_discount
 
class TaxProcessor():
    def process(self, cart_items):
        total_tax=0
        for item in cart_items:
            total_tax+=(item.product.product_tax * item.product_count)
        return total_tax
 
class FinalPriceProcessor():
    def process(self, cart_items):
        total_price=0
        for item in cart_items:
            price=item.product.product_price
            discount=item.product.product_discount
            tax=item.product.product_tax
            quantity=item.product_count
 
            total_price+=(price-discount+tax)*quantity
        return total_price
 
class DeliveryFeeProcessor:
    def process(self, cart):
        return cart.delivery_fee
 