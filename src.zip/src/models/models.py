from typing import List
from uuid import UUID
from datetime import datetime

from pydantic import BaseModel, Field, field_validator
# If you really want to keep using the old decorator:
# from pydantic import validator  # but prefer field_validator in Pydantic v2

# ❌ Do not import SQLAlchemy types for Pydantic DTOs
# from sqlalchemy import Float


class OrderItemDTO(BaseModel):
    product_id: int = Field(..., gt=0)
    quantity: int = Field(..., ge=1)


class CreateOrderRequestDTO(BaseModel):
    customer_id: int = Field(..., gt=0)
    items: List[OrderItemDTO]

    # Pydantic v2 style validator
    @field_validator("items")
    @classmethod
    def items_not_empty(cls, v: List[OrderItemDTO]) -> List[OrderItemDTO]:
        if not v:
            raise ValueError("Items list cannot be empty")
        return v


class UpdateCartItemRequestDTO(BaseModel):
    customer_id: int = Field(..., gt=0)
    product_id: int = Field(..., gt=0)
    quantity: int = Field(..., ge=0)  # allow 0 to remove? adjust per your use-case


class ProductResponseDTO(BaseModel):
    product_name: str = Field(..., min_length=1, max_length=100)
    quantity: int = Field(..., ge=1)
    price: float = Field(..., ge=0)
    tax: float = Field(0.0, ge=0)         # ✅ use python float (or Decimal variant below)
    discount: int = Field(0, ge=0, le=100)


class OrderCreateSuccessResponseDTO(BaseModel):
    request_id: UUID
    status: int = Field(..., ge=100, le=599)
    message: str = Field(..., min_length=1)
    cart_id: int = Field(..., gt=0)
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class OrderDataDTO(BaseModel):
    customer_name: str = Field(..., min_length=1)
    products: List[ProductResponseDTO]


class CartUpdateSuccessResponseDTO(BaseModel):
    request_id: UUID
    status: int
    message: str


class ErrorResponseDTO(BaseModel):
    status: int = Field(..., ge=100, le=599)
    message: str = Field(..., min_length=1)
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class ProcessOrderRequest(BaseModel):
    cart_id: int = Field(..., gt=0)


# Fix typo: Requet -> Request (if both are needed, keep both with different purposes)
class ProcessOrderIdRequest(BaseModel):
    order_id: int = Field(..., gt=0)