# routes/GetRouter.py

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from repositories.database import db_instance  # <-- use your singleton instance
from repositories.HealthRepository import HealthRepository
from services.HealthService import HealthService


def get_repo(db: Session = Depends(db_instance.get_session)) -> HealthRepository:
    return HealthRepository(db)

def get_service(repo: HealthRepository = Depends(get_repo)) -> HealthService:
    return HealthService(repo)


class GetRouter:
    order_router = APIRouter()

    @order_router.get(
        "/health",
        status_code=200,
        summary="System health (no params)",
        response_description="Simple success response indicating system health",
    )
    def get_health_router(service: HealthService = Depends(get_service)):
        try:
            return service.get_health_service()
        except Exception as exc:
            # Optional: map unexpected errors to 500
            raise HTTPException(status_code=500, detail=f"Health check failed: {exc}")