# routes/GetRouter.py

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from repositories.database import Database
from repositories.GetRepository import GetRepository
from services.GetService import GetService

# Create a single provider instance (OK for simple apps)
db_provider = Database()

# Dependency: yield a live session and return a repo instance
def get_repo(db: Session = Depends(db_provider.get_session)) -> GetRepository:
    return GetRepository(db) 
 # <-- return instance, not class

def get_service(repo: GetRepository=Depends(get_repo)):
    return GetService()

class GetRouter:
    order_router = APIRouter()

    @order_router.get(
        "/Order/{cart_id}",
        
        status_code=200,
    )
    def get_order_router(
        cart_id: int,
        service: GetService=Depends(get_service)  # <-- depends on the function above
    ):
       
        data = service.get_cart_service(cart_id)
        return data