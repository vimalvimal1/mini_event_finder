from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
import uuid
 
from repositories.database import Database
from repositories.CreateRepository import CreateRepository
from services.CreateService import CreateService
from models.models import CreateOrderRequestDTO
from models.models import OrderCreateSuccessResponseDTO
 
order_router = APIRouter()
 
db_provider = Database()
 
def get_repo(db: Session = Depends(db_provider.get_session)):
    return CreateRepository(db)
 
 
@order_router.post("/order", response_model=OrderCreateSuccessResponseDTO, status_code=201)
def create_order_router(
        request: CreateOrderRequestDTO,
        repo: CreateRepository = Depends(get_repo)
):
    service = CreateService(repo)
 
    order = service.create_order(request)
 
    return OrderCreateSuccessResponseDTO(
        request_id=uuid.uuid4(),
        status=201,
        message="Order created successfully",
        cart_id=order.cart_id
    )
 