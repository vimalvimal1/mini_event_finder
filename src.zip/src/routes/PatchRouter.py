from sqlalchemy.orm import Session
from repositories.PatchRepository import PatchRepository
from repositories.database import Database
from fastapi import APIRouter, Depends

from models.models import UpdateCartItemRequestDTO, CartUpdateSuccessResponseDTO
from services.PatchService import PatchService
import uuid
class PatchRouter:
    order_router = APIRouter()
    db_provider=Database()
    def get_repo(db: Session = Depends(db_provider.get_session)) -> PatchRepository:
        return PatchRepository(db)
 
 
    @order_router.patch(
    "/Order/{order_id}",
    response_model=CartUpdateSuccessResponseDTO,
    status_code=200
    )
    def patch_order_router(request: UpdateCartItemRequestDTO,repo: PatchRepository = Depends(get_repo)):
        
        service = PatchService(repo)

        response_dto= CartUpdateSuccessResponseDTO(
           request_id=uuid.uuid4(),
            status=200,
            message="Order updated Successfully")
        return response_dto.dict()
            
        
       
