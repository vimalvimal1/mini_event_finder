from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from repositories.database import db_instance
from repositories.OrderRepository import OrderRepository
from services.OrderService import OrderService
 
 

class ProcessRouter:
    
    order_router= APIRouter()
    @order_router.post("/place_order")
    def create_order(cart_id: int, db: Session = Depends(db_instance.get_session)):
 
        repo = OrderRepository(db)
        service = OrderService(repo)
 
        order = service.create_order(cart_id)
        
        return {
        "status_code": 201,
        "message": "Order created successfully",
        "order_id": order.order_id,
        "final_amount": float(order.final_amount)
        }