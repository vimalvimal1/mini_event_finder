from repositories.schemas.schemas import Base
from repositories.database import Database
class Migration:
    @staticmethod
    def create_tables():
    
        db_instance = Database()
        Base.metadata.create_all(bind=db_instance._engine)
        print("Tables created successfully!")
 
    if __name__ == "__main__":
        create_tables()