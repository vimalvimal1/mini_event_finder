from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routes.ProcessRouter import ProcessRouter
from routes.PatchRouter import PatchRouter
from routes.GetRouter import GetRouter
from logger.logger import get_default_logger
from repositories.database import Database
from migrations.create_tables import Migration
from seeder.seeder import Seeder
from routes.CreateRouter import order_router
from routes.HealthRouter import GetRouter

# Avoid importing uvicorn at top-level in environments that import this module.
# We'll import uvicorn only inside the __main__ guard to reduce side effects on Windows.

logger = get_default_logger()

# Keep globals minimal and import-safe
db_connection = None

def initialize_config() -> bool:
    """Initialize configuration and database connection"""
    global db_connection
    try:
        db_connection = Database()
        logger.info("Database connection initialized")

        # Optionally, test connection
        if db_connection.test_connection():
            logger.info("Database test connection successful")
        else:
            logger.warning("Database test connection failed")
        return True
    except Exception as e:
        logger.error(f"Failed to initialize configuration: {e}")
        return False


app = FastAPI(
    title="Order Management API",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"],
    allow_headers=[
        "Accept",
        "Accept-Language",
        "Content-Language",
        "Content-Type",
        "Authorization",
        "accessToken",
        "deviceIdentifier",
        "X-RequestID",
        "X-Requested-With",
        "Origin",
        "Cache-Control",
        "Pragma",
    ],
    expose_headers=["*"],
    max_age=3600,
)
app.include_router(GetRouter.order_router,prefix="/api",tags=["orders"])
app.include_router(order_router, prefix="/api", tags=["orders"])
app.include_router(PatchRouter.order_router,  prefix="/api", tags=["orders"])
app.include_router(GetRouter.order_router,    prefix="/api", tags=["orders"])
app.include_router(ProcessRouter.order_router,prefix="/api",tags=["orders"])


# ------------------------------
# Startup / Shutdown lifecycle
# ------------------------------

@app.on_event("startup")
def on_startup():
    """
    Run import-safe initialization here.
    With --reload, this runs in the worker process each time it restarts.
    Ensure migration/seeding are idempotent.
    """
    logger.info("Startup: initializing configuration...")
    if not initialize_config():
        raise RuntimeError("Failed to initialize configuration on startup")

    if not db_connection or not db_connection.test_connection():
        raise RuntimeError("Database connection test failed on startup")

    try:
        migration = Migration()
        migration.create_tables()
        logger.info("Database tables ensured/created successfully")

        seeder = Seeder()
        seeder.seed_data()  
        logger.info("Database seeded successfully (idempotent)")
    except Exception as e:
        logger.warning(f"Migration/Seeding encountered an issue: {e}")


@app.on_event("shutdown")
def on_shutdown():
    try:
        if db_connection:
            db_connection.close()  # if your Database() exposes a close
            logger.info("Database connection closed")
    except Exception as e:
        logger.warning(f"Error during shutdown cleanup: {e}")




@app.get("/")
def health_check():
    return {
        "status": "running",
        "message": "Order management API is active",
    }




if __name__ == "__main__":
    
    import multiprocessing
    multiprocessing.freeze_support() 

    import uvicorn


    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,  
    )