from fastapi import HTTPException
from sqlalchemy.orm import Session
from repositories.schemas.schemas import Cart,CartItem,Order
 
 
class OrderRepository:
 
    def __init__(self, db: Session):
        self.db = db
 
    def get_cart(self, cart_id: int):
        return self.db.query(Cart).filter(
            Cart.cart_id == cart_id,
            Cart.is_active == True
        ).first()
 
    def get_cart_items(self, cart_id: int):
        return self.db.query(CartItem).filter(
            CartItem.cart_id == cart_id,
            CartItem.is_active == True
        ).all()
 
    def create_order(self, order: Order):
        try:
            self.db.add(order)
            self.db.commit()
            self.db.refresh(order)
            return order
        except Exception as e:
             self.db.rollback()
             raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    

 