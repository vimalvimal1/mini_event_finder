# database.py
 
from sqlalchemy import create_engine, text, inspect
from sqlalchemy.orm import sessionmaker, Session
from settings import config
 
 
class Database:
    _instance = None
    _engine = None
 
    def __new__(cls):
        if cls._instance is None:
            print("Creating DB Engine...")  # Should print only once
            cls._instance = super(Database, cls).__new__(cls)
 
            # Create engine only once
            cls._engine = cls._create_engine()
 
            # Create Session factory only once
            cls._instance.SessionLocal = sessionmaker(
                bind=cls._engine,
                autoflush=False,
                autocommit=False
            )
 
        return cls._instance
 
    @staticmethod
    def _create_engine():
        db_url = (
            f"postgresql+psycopg2://"
            f"{config.db_username}:"
            f"{config.db_password}@"
            f"{config.db_host}:"
            f"{config.db_port}/"
            f"{config.db_name}"
        )
 
        return create_engine(
            db_url,
            pool_pre_ping=True,
            echo=False
        )
 
    # FastAPI dependency generator
    def get_session(self):
        session: Session = self.SessionLocal()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()
 
    def inspector(self):
        return inspect(self._engine)
 
    def test_connection(self) -> bool:
        try:
            with self._engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            return True
        except Exception as e:
            print(f"DB connection failed: {e}")
            return False
 
 
# Singleton instance
db_instance = Database()
 