
from repositories.database import db_instance

class HealthRepository:
    def __init__(self, repo: HealthRepository) -> None:
        self.repo = repo

    def get_health_service(self) -> dict:
        # Engine-level check:
        if not db_instance.test_connection():
            return {
                "status": "error",
                "message": "DB connection failed",
                "data": {"healthy": False}
            }
        # Optional: also touch the session (comment out if not needed)
  
        return {
            "status": "success",
            "message": "System health OK",
            "data": {"healthy": True}
        }
