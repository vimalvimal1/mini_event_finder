

from sqlalchemy.orm import Session, joinedload
from fastapi import HTTPException
from repositories.schemas.schemas import Customer, Product, Cart, CartItem

class GetRepository:
    def __init__(self,db: Session):
        self.db=db
   
    
    def get_cart_repo(self, cart_id: int):
        try:
            data = (
                self.db.query(Cart)
                .options(
                    joinedload(Cart.customer),
                    joinedload(Cart.cart_items).joinedload(CartItem.product),
                )
                .filter(Cart.cart_id == cart_id)
                .first()
            )
            return data
        except Exception as e:
            self.db.rollback()
            raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")

