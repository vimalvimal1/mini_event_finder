from repositories.schemas.schemas import Customer, Product, Cart, CartItem
 
 
class CreateRepository:
 
    def __init__(self, db):
        self.db = db
 
    # ✅ only DB fetch
    def get_customer_by_id(self, customer_id):
        return self.db.query(Customer).filter(
            Customer.customer_id == customer_id
        ).first()
 
    def get_product_by_id(self, product_id):
        return self.db.query(Product).filter(
            Product.product_id == product_id
        ).first()
 
    # ✅ main order creation
    def create_order_repository(self, customer_id, items):
 
        try:
            # deactivate existing cart
            self.db.query(Cart).filter(
                Cart.customer_id == customer_id,
                Cart.is_active == True
            ).update({Cart.is_active: False})
 
            # create new cart
            new_cart = Cart(
                customer_id=customer_id,
                created_by="system",
                is_active=True
            )
 
            self.db.add(new_cart)
            self.db.flush()  # generate cart_id
 
            # add items + reduce stock
            for item in items:
                product = self.get_product_by_id(item.product_id)
 
                # ✅ reduce stock
                product.stock_quantity -= item.quantity
 
                cart_item = CartItem(
                    cart_id=new_cart.cart_id,
                    product_id=item.product_id,
                    quantity=item.quantity,
                    created_by="system",
                    is_active=True
                )
 
                self.db.add(cart_item)
 
            self.db.commit()
            self.db.refresh(new_cart)
 
            return new_cart
 
        except Exception as e:
            self.db.rollback()
            raise e
 