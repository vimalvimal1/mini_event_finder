from sqlalchemy import Column, Float, Integer, String, ForeignKey,  DateTime,Text,DECIMAL,Boolean
from sqlalchemy.sql import func
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
 
 
Base=declarative_base()
 
class Customer(Base):
    __tablename__ = "Customers"
 
    customer_id = Column(Integer, primary_key=True, index=True)
    customer_name = Column(String(50), nullable=False)
    phone_number=Column(String(10),unique=True, nullable=False)
    email = Column(String(100), nullable=False, unique=True)
    address=Column(Text,nullable=False)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    created_by = Column(String(50),nullable=False,default="vimal")
    updated_by = Column(String(50))
    is_active=Column(Boolean , nullable=False)
 
    carts=relationship("Cart",back_populates="customer")

class Product(Base):
    __tablename__ = "Products"
 
    product_id = Column(Integer, primary_key=True, index=True)
    product_name = Column(String(100), nullable=False)
    product_price = Column(DECIMAL(10, 2), nullable=False)
    product_discount=Column(Integer)
    product_tax=Column(DECIMAL(10,2),nullable=False)
    product_quantity= Column(Integer, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    created_by = Column(String(50),nullable=False,default="vimal")
    updated_by = Column(String(50))
    is_active=Column(Boolean , nullable=False)

    cart_items=relationship("CartItem",back_populates="product")
 

 
class Cart(Base):
    __tablename__ = "Cart"
 
    cart_id = Column(Integer, primary_key=True, index=True)
    customer_id = Column(Integer, ForeignKey("Customers.customer_id", ondelete="CASCADE"))
    delivery_fee=Column(Float,nullable=True, default=0)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    created_by = Column(String(50),nullable=False,default="vimal")
    updated_by = Column(String(50))
    is_active=Column(Boolean , nullable=False)
 
    customer=relationship("Customer",back_populates="carts")
    cart_items=relationship("CartItem",back_populates="cart")
 

class CartItem(Base):
    __tablename__ = "Cart_items"
 
    cart_item_id = Column(Integer, primary_key=True, index=True)
    cart_id = Column(Integer, ForeignKey("Cart.cart_id", ondelete="CASCADE"))
    product_id = Column(Integer, ForeignKey("Products.product_id", ondelete="CASCADE"))
    product_count = Column(Integer, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    created_by = Column(String(50),nullable=False,default="vimal")
    updated_by = Column(String(50))
    is_active=Column(Boolean , nullable=False)

    cart=relationship("Cart",back_populates="cart_items")
    product=relationship("Product",back_populates="cart_items")

class Order(Base):
    __tablename__ = "Orders"
 
    order_id = Column(Integer, primary_key=True, index=True)
 
    customer_id = Column(
        Integer,
        ForeignKey("Customers.customer_id", ondelete="CASCADE"),
        nullable=False
    )
 
    cart_id = Column(
        Integer,
        ForeignKey("Cart.cart_id", ondelete="CASCADE"),
        nullable=False
    )
 
    # 💰 Money Snapshot Fields
    subtotal = Column(DECIMAL(10, 2), nullable=False)
    tax_amount = Column(DECIMAL(10, 2), nullable=False)
    discount_amount = Column(DECIMAL(10, 2), nullable=False)
    delivery_fee = Column(DECIMAL(10, 2), nullable=False, default=0)
    final_amount = Column(DECIMAL(10, 2), nullable=False)
 
    payment_status = Column(String(50), nullable=False, default="PENDING")
 
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    created_by = Column(String(50), nullable=False, default="vimal")
    updated_by = Column(String(50))
    is_active = Column(Boolean, nullable=False)
 
    # 🔗 Relationships
    customer = relationship("Customer")
    cart = relationship("Cart")
 
 

 


 
