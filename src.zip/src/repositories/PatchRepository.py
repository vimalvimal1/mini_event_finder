

from sqlalchemy.orm import Session
from fastapi import HTTPException
from repositories.schemas.schemas import Customer, Product, Cart, CartItem

class PatchRepository:
    def __init__(self, db: Session):
        self.db = db

    def get_customer_by_id(self, customer_id: int) -> Customer:
        customer = (
            self.db.query(Customer)
            .filter(Customer.customer_id == customer_id)
            .first()
        )
        if not customer:
            raise HTTPException(status_code=404, detail="Customer not found")
        return customer

    def get_product_by_id(self, product_id: int) -> Product:
        product = (
            self.db.query(Product)
            .filter(Product.product_id == product_id)
            .first()
        )
        if not product:
            raise HTTPException(
                status_code=404, detail=f"Product {product_id} not found"
            )
        return product

    def check_product_quantity(self, product_id: int, desired_quantity: int) -> None:
        product = self.get_product_by_id(product_id)
        if product.product_quantity < desired_quantity:
            raise HTTPException(
                status_code=400,
                detail=f"Insufficient quantity for product {product_id}",
            )

    def patch_order_repository(self, customer_id: int, product_id: int, quantity: int):
        try:
            # Deactivate any previous active carts for the customer
            (
                self.db.query(Cart)
                .filter(Cart.customer_id == customer_id, Cart.is_active == True)
                .update({Cart.is_active: False})
            )

            # Create new cart
            new_cart = Cart(
                customer_id=customer_id,
                created_by="system",
                is_active=True,
            )
            self.db.add(new_cart)
            self.db.flush()  # to populate new_cart.cart_id

            # Add the single cart item
            cart_item = CartItem(
                cart_id=new_cart.cart_id,
                product_id=product_id,
                product_count=quantity,  # adjust if your schema differs
                created_by="system",
                is_active=True,
            )
            self.db.add(cart_item)

            self.db.commit()
            self.db.refresh(new_cart)
            return new_cart

        except Exception as e:
            self.db.rollback()
            raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")