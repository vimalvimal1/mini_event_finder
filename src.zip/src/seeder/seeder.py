from repositories.database import Database
from repositories.schemas.schemas import Customer, Product, Cart, CartItem
 
class Seeder:
 
    @staticmethod
    def seed_data():
        db_instance = Database()  
 
        with db_instance.get_session() as db:
            try:
               
                customers = [
                    Customer(
                        customer_name="Vimal",
                        phone_number="9999999999",
                        email="vimal@gmail.com",
                        address="Chennai",
                        created_by="seed",
                        is_active=True
                    ),
                    Customer(
                        customer_name="Arun",
                        phone_number="8888888888",
                        email="arun@gmail.com",
                        address="Bangalore",
                        created_by="seed",
                        is_active=True
                    ),
                ]
                db.add_all(customers)
                db.flush()  # Assigns customer_id automatically
 
                products = [
                    Product(
                        product_name="Protein Bar",
                        product_price=50.0,
                        product_quantity=100,
                        product_discount=0,
                        product_tax=5.0,
                        created_by="seed",
                        is_active=True
                    ),
                    Product(
                        product_name="Dumbbell",
                        product_price=500.0,
                        product_quantity=20,
                        product_discount=0,
                        product_tax=10.0,
                        created_by="seed",
                        is_active=True
                    ),
                    Product(
                        product_name="Shaker",
                        product_price=150.0,
                        product_quantity=50,
                        product_discount=0,
                        product_tax=5.0,
                        created_by="seed",
                        is_active=True
                    ),
                ]
                db.add_all(products)
                db.flush()  # Assigns product_id automatically
 
              
 
                print(" Seed data inserted successfully!")
 
            except Exception as e:
                db.rollback()
                print(f"Error inserting seed data: {e}")
 