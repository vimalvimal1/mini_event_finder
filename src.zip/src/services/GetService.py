# services/GetService.py
from decimal import Decimal

from fastapi import HTTPException
from repositories.GetRepository import GetRepository
from utils.processor.state_transfer import (
    DeliveryFeeProcessor, DiscountProcessor, FinalPriceProcessor, TaxProcessor
)

class GetService:
    def __init__(self, repo: GetRepository):
        self.repo = repo

    def get_cart_service(self, cart_id: int):
        cart = self.repo.get_cart_repo(cart_id)
        if not cart:
            raise HTTPException(status_code=404, detail="Cart not found")

        discount = Decimal(DiscountProcessor().process(cart.cart_items))
        tax = Decimal(TaxProcessor().process(cart.cart_items))
        subtotal = Decimal(FinalPriceProcessor().process(cart.cart_items))
        delivery_fee = Decimal(DeliveryFeeProcessor().process(cart))
        
        total = (subtotal)+delivery_fee

        return {
            "customer_name": cart.customer.customer_name,  # rename if DTO expects 'customer_name'
            "products": [
                {
                    "product_name": item.product.product_name,
                    "quantity": item.product_count,  # ensure this matches your model
                    "product_price": item.product.product_price,
                    "product_tax": item.product.product_tax,
                    "product_discount": item.product.product_discount,
                }
                for item in cart.cart_items
            ],
            "total_discount": discount,
            "total_tax": tax,
            "delivery_fee": delivery_fee,
            "total_price": total,
        }