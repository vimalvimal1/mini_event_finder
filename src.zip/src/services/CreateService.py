from fastapi import HTTPException
from repositories.CreateRepository import CreateRepository
 
class CreateService:
 
    def __init__(self, repo:CreateRepository):
        self.repo = repo
 
    def create_order(self, request):
 
        # ✅ customer validation
        customer = self.repo.get_customer_by_id(request.customer_id)
        if not customer:
            raise HTTPException(status_code=404, detail="Customer not found")
 
        # ✅ product validation + stock validation
        for item in request.items:
            product = self.repo.get_product_by_id(item.product_id)
 
            if not product:
                raise HTTPException(
                    status_code=404,
                    detail=f"Product {item.product_id} not found"
                )
 
            if product.product_quantity < item.quantity:
                raise HTTPException(
                    status_code=400,
                    detail=f"Insufficient stock for product {item.product_id}"
                )
 
       
        order = self.repo.create_order_repository(
            customer_id=request.customer_id,
            items=request.items
        )
 
        return order