

from fastapi import HTTPException
from repositories.PatchRepository import PatchRepository
from repositories.database import Database
 
 
class PatchService:
 
    def __init__(self, repo: PatchRepository):
        self.repo = repo
        
    
    # @classmethod
    
    # def create(cls):
    #     db_instance = Database()
    #     SessionLocal = db_instance.get_session()  # returns sessionmaker
    #     db = SessionLocal()                       # create open session

    #     repo = PatchRepository(db)
    #     return cls(repo, db)

 
    def patch_order_service(self, request) -> dict:
        # Validate customer exists
        customer = self.repo.get_customer_by_id(request.customer_id)
 
        if not customer:
            raise HTTPException(
                status_code=404,
                detail="Customer not found"
            )
 

        # Validate product exists and has stock
        product = self.repo.get_product_by_id(request.product_id)
        if product.product_quantity < request.quantity:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"Insufficient stock for product. "
                    f"Cannot add stock {request.product_id}"
                ),
            )

        # Create/patch order
        cart = self.repo.patch_order_repository(
            customer_id=request.customer_id,
            product_id=request.product_id,
            quantity=request.quantity,
        )

        
        return cart