from decimal import Decimal
from fastapi import HTTPException
from repositories.schemas.schemas import Order
from utils.processor.state_transfer import (
    DiscountProcessor,
    DeliveryFeeProcessor,
    TaxProcessor,
    FinalPriceProcessor
)
from services.handlers import (
    FraudHandler,
    InventoryHandler,
    PaymentHandler,
    ConfirmationHandler
)
 
class OrderService:
 
    def __init__(self, repo):
        self.repo = repo
        self.discount_processor = DiscountProcessor()
        self.tax_processor = TaxProcessor()
        self.final_processor = FinalPriceProcessor()
        self.delivery_processor = DeliveryFeeProcessor()
 
        
        self.fraud_handler = FraudHandler(repo)
        self.inventory_handler = InventoryHandler(repo)
        self.payment_handler = PaymentHandler(repo)
        self.confirmation_handler = ConfirmationHandler(repo)
 
        
        self.fraud_handler.set_next(self.inventory_handler)\
                          .set_next(self.payment_handler)\
                          .set_next(self.confirmation_handler)
 
    def create_order(self, cart_id: int):
 
        cart = self.repo.get_cart(cart_id)
        if not cart:
            raise HTTPException(status_code=404, detail="Cart not found")
 
        cart_items = self.repo.get_cart_items(cart_id)
        if not cart_items:
            raise HTTPException(status_code=400, detail="Cart is empty")
    
        subtotal = Decimal("0")
        for item in cart_items:
            price = Decimal(item.product.product_price)
            quantity = Decimal(item.product_count)
            subtotal += price * quantity
 
        total_tax = self.tax_processor.process(cart_items)
        total_discount = self.discount_processor.process(cart_items)
        delivery_fee = self.delivery_processor.process(cart)
        delivery_fee = Decimal(delivery_fee or 0)
 
        final_amount = subtotal + total_tax - total_discount + delivery_fee
 
        order = Order(
            customer_id=cart.customer_id,
            cart_id=cart.cart_id,
            subtotal=subtotal,
            tax_amount=total_tax,
            discount_amount=total_discount,
            delivery_fee=delivery_fee,
            final_amount=final_amount,
            payment_status="PAID",
            is_active=True
        )
 
        handler_result = self.fraud_handler.handle(order)
        if handler_result.get("status") != 200:
            raise HTTPException(
                status_code=handler_result.get("status", 400),
                detail=handler_result.get("message", "Order failed at handler")
            )
 
        created_order = self.repo.create_order(order)

        return created_order
 