# services/HealthService.py

from repositories.HealthRepository import HealthRepository

class HealthService:
    def __init__(self, repo: HealthRepository) -> None:
        self.repo = repo

    def get_health_service(self) -> dict:
        # Add any business rules / extra checks here.
        return self.repo.get_health_service()