from abc import ABC, abstractmethod
from repositories.schemas.schemas import Customer, CartItem

class OrderHandler(ABC):
    def __init__(self):
        self._next_handler = None
 
    def set_next(self, handler: "OrderHandler"):
        self._next_handler = handler
        return handler
 
    def call_next(self, order):
        if self._next_handler:
            return self._next_handler.handle(order)
        return {"status": 200, "message": "Order processed successfully"}
 
    @abstractmethod
    def handle(self, order):
        pass
 

class FraudHandler(OrderHandler):
    def __init__(self, repo):
        super().__init__()
        self.repo = repo
 
    def handle(self, order):
        customer = self.repo.db.query(Customer).filter(
            Customer.customer_id == order.customer_id
        ).first()
 
        if not customer:
            return {"status": 404, "message": "Customer not found", "stage": "Fraud"}
        if not customer.is_active:
            return {"status": 400, "message": "Customer is inactive", "stage": "Fraud"}
 
        return self.call_next(order)
 

class InventoryHandler(OrderHandler):
    def __init__(self, repo):
        super().__init__()
        self.repo = repo
 
    def handle(self, order):
        # Direct DB query to check cart items
        cart_items = self.repo.db.query(CartItem).filter(
            CartItem.cart_id == order.cart_id
        ).all()
 
        if not cart_items:
            return {"status": 400, "message": "Cart is empty", "stage": "Inventory"}
        return self.call_next(order)
 

class PaymentHandler(OrderHandler)  :
    def __init__(self, repo):
        super().__init__()
        self.repo = repo
    def handle(self, order):
        if getattr(order, "payment_status", None) != "PAID":
            return {"status": 400, "message": "Payment not completed", "stage": "Payment"}
        return self.call_next(order)
 

class ConfirmationHandler(OrderHandler):
    def __init__(self, repo):
        super().__init__()
        self.repo = repo
    def handle(self, order):
        return self.call_next(order)