from pydantic import BaseModel

from typing import Optional
class RequestDTO(BaseModel):
    customer_name:Optional[str]=""
    query:str