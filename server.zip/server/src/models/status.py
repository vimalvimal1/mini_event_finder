from enum import Enum



class OrderStatus(str, Enum):
    pending = "pending"
    ordered = "ordered"