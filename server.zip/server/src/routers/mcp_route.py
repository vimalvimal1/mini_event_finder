from fastmcp import FastMCP


router = FastMCP("router")
from tools.tool import tool
