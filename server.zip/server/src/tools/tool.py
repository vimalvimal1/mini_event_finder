
from langchain.tools import tool
from repositories.repo import OrderRepository
from repositories.Database.database import db_provider
from routers.mcp_route import router

def get_repo():
    db = next(db_provider.get_session())
    return OrderRepository(db)

@router.tool
def check_menu():
    """Return all menu items available in the café."""
    repo = get_repo()
    menu = repo.check_menu()
    return {"type": "menu", "items": menu}

@router.tool
def place_order(customer_id: int, item_name: str, quantity: int = 1):
    """Place an order for the customer."""
    repo = get_repo()
    result = repo.place_order(customer_id, item_name, quantity)
    return {"type": "order", "message": result}

@router.tool
def check_inventory(menu_id):
    """Check inventory for a menu item."""
    repo = get_repo()
    qty = repo.check_inventory(menu_id)
    return {"type": "inventory", "menu_id":menu_id, "quantity": qty}

@router.tool
def check_order_status(order_id: int):
    """Check current status of an order."""
    repo = get_repo()
    status = repo.get_order_status(order_id)
    return {"type": "order_status", "status": status}

@router.tool
def generate_bill(order_id: int):
    """Generate total bill for the order."""
    repo = get_repo()
    bill = repo.generate_bill(order_id)
    return {"type": "bill", "bill": bill}

@router.tool
def get_or_create_customer(customer_name: str):
    """Check if customer exists by name, create if not. Always call this first."""
    repo = get_repo()
    result = repo.get_or_create_customer(customer_name)
    return {"type": "customer", "customer_id": result["customer_id"], "name": result["name"]}