from fastmcp import FastMCP
from routers.mcp_route import router
import uvicorn

mcp = FastMCP("my-server")
mcp.mount(router)

mcp.run(transport="streamable-http")



    
if __name__ == "__main__":
    
    uvicorn.run(
        "mcp:mcp",
        host="0.0.0.0",
        port=8080,
        reload=True,
        log_level="info"
    )