from sqlalchemy import (
    Column, Float, Integer, Date, DateTime, String, ForeignKey, CheckConstraint, Boolean, UniqueConstraint, func, text
)
from sqlalchemy.orm import mapped_column, relationship, declarative_base
from models.status import OrderStatus
from sqlalchemy import Enum as SAEnum
Base = declarative_base()

class Customer(Base):
    __tablename__ = "customers"
    customer_id = Column(Integer, primary_key=True, autoincrement=True)
    customer_uuid = Column(String, server_default=text("gen_random_uuid()"), unique=True, index=True)
    customer_name = Column(String, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    created_by = Column(String, default="SYSTEM", nullable=False)
    updated_at = Column(DateTime, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    updated_by = Column(String, default="SYSTEM", nullable=False)

    
    orders = relationship("Order", back_populates="customers")


class Menu(Base):
    __tablename__="menus"
    menu_item_id=Column(Integer,primary_key=True,autoincrement=True)
    menu_item_uuid=Column(String, server_default=text("gen_random_uuid()"), unique=True, index=True)
    menu_item_name=Column(String, nullable=False)
    price=Column(Float, nullable= False)
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    created_by = Column(String, default="SYSTEM", nullable=False)
    updated_at = Column(DateTime, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    updated_by = Column(String, default="SYSTEM", nullable=False)

    
    inventory = relationship("Inventory", back_populates="menus")
    

class Inventory(Base):
    __tablename__="inventory"
    item_id=Column(Integer,primary_key=True,autoincrement=True)
    item_uuid=Column(String, server_default=text("gen_random_uuid()"), unique=True, index=True)
    menu_item_id=Column(Integer, ForeignKey("menus.menu_item_id", ondelete="CASCADE"),nullable=False, index=True)
    item_quantity=Column(Integer,default=30,nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    created_by = Column(String, default="SYSTEM", nullable=False)
    updated_at = Column(DateTime, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    updated_by = Column(String, default="SYSTEM", nullable=False)

    
    menus= relationship("Menu", back_populates="inventory")
    order_items = relationship("OrderItem", back_populates="inventory")


class Order(Base):
    __tablename__="orders"
    order_id=Column(Integer,primary_key=True,autoincrement=True)
    order_uuid=Column(String, server_default=text("gen_random_uuid()"), unique=True, index=True)
    customer_id=Column(Integer, ForeignKey("customers.customer_id", ondelete="CASCADE"),nullable=False, index=True)
    # bill_amount=Column(Float, nullable= False)
    order_status=mapped_column(
        SAEnum(
            OrderStatus,
            name="cart_status_enum",   
            native_enum=True,         
            validate_strings=True
        ),default="ordered")
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    created_by = Column(String, default="SYSTEM", nullable=False)
    updated_at = Column(DateTime, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    updated_by = Column(String, default="SYSTEM", nullable=False)

    
    customers = relationship("Customer", back_populates="orders")
    order_items = relationship("OrderItem", back_populates="orders")


class OrderItem(Base):
    __tablename__="order_items"
    order_item_id=Column(Integer,primary_key=True,autoincrement=True)
    item_id=Column(Integer, ForeignKey("inventory.item_id", ondelete="CASCADE"),nullable=False, index=True)
    order_id=Column(Integer, ForeignKey("orders.order_id", ondelete="CASCADE"),nullable=False, index=True)
    ordered_quantity=Column(Integer, default=1, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    created_by = Column(String, default="SYSTEM", nullable=False)
    updated_at = Column(DateTime, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    updated_by = Column(String, default="SYSTEM", nullable=False)

    
    inventory = relationship("Inventory", back_populates="order_items")
    orders = relationship("Order", back_populates="order_items")


class ErrorLog(Base):
    __tablename__="errors"
    error_id=Column(Integer,primary_key=True,autoincrement=True)
    file_name=Column(String(255),nullable= False)
    function_name=Column(String(255),nullable= False)
    error_message=Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    created_by = Column(String, default="SYSTEM", nullable=False)
    updated_at = Column(DateTime, server_default=text("CURRENT_TIMESTAMP"), nullable=False)
    updated_by = Column(String, default="SYSTEM", nullable=False)
