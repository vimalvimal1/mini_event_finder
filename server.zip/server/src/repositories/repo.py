from sqlalchemy.orm import Session
from sqlalchemy import select, func
 
from repositories.schemas.schema import Menu, Inventory, Order, OrderItem, ErrorLog, Customer
 
 
class OrderRepository:
 
    def __init__(self, db: Session):
        self.db = db
 
    def check_menu(self):
 
        stmt = select(Menu).where(Menu.is_active == True)
 
        menus = self.db.execute(stmt).scalars().all()
 
        if not menus:
            return "Menu is empty"
 
        menu_list = []
 
        for menu in menus:
            menu_list.append({
                "menu_item_id": menu.menu_item_id,
                "menu_item_name": menu.menu_item_name,
                "price": menu.price
            })
 
        return menu_list
 
 

    def check_inventory(self, menu_id: int):
    
        stmt = select(Inventory).where(
            Inventory.menu_item_id == menu_id,
            Inventory.is_active == True
        )
    
        inventory: Inventory | None = self.db.execute(stmt).scalar_one_or_none()
    
        if inventory is None:
            return "Inventory record not found"
    
        qty= inventory.item_quantity
    
        return qty
 
 
    def place_order(self, customer_id: int, item_name: str, quantity: int):
 
        menu_stmt = select(Menu).where(
            func.lower(Menu.menu_item_name) == item_name.lower()
        )
 
        menu = self.db.execute(menu_stmt).scalar_one_or_none()
 
        if menu is None:
            return f"{item_name} not found in menu"
 
 
        inventory_stmt = select(Inventory).where(
            Inventory.menu_item_id == menu.menu_item_id
        )
 
        inventory = self.db.execute(inventory_stmt).scalar_one_or_none()
 
        if inventory is None:
            return "Inventory record not found"
 
 
        available_qty = inventory.item_quantity
 
 
        
        order = Order(
            customer_id=customer_id,
            order_status="ordered"
        )
 
        self.db.add(order)
        self.db.commit()
        self.db.refresh(order)
 
 
       
        order_item = OrderItem(
            order_id=order.order_id,
            item_id=inventory.item_id,
            ordered_quantity=quantity
        )
 
        self.db.add(order_item)
        self.db.commit()
        self.db.refresh(order_item)

 
        return {
            "message": "Order placed successfully",
            "order_id": order.order_id
        }
 
 

    def get_order_status(self, order_id: int):
 
        stmt = select(Order).where(Order.order_id == order_id)
 
        order = self.db.execute(stmt).scalar_one_or_none()
 
        if order is None:
            return "Order not found"
 
        return {
            "order_id": order.order_id,
            "status": str(order.order_status)
        }
 
 
    
    def generate_bill(self, order_id: int):
 
        stmt = (
            select(
                Menu.menu_item_name,
                Menu.price,
                OrderItem.ordered_quantity
            )
            .join(Inventory, Inventory.item_id == OrderItem.item_id)
            .join(Menu, Menu.menu_item_id == Inventory.menu_item_id)
            .where(OrderItem.order_id == order_id)
        )
 
        results = self.db.execute(stmt).all()
 
        if not results:
            return "No items found for this order"
 
 
        total_amount = 0
        bill_items = []
 
        for row in results:
 
            name = row.menu_item_name
            price = float(row.price)
            quantity = int(row.ordered_quantity)
 
            subtotal = price * quantity
            total_amount += subtotal
 
            bill_items.append({
                "item_name": name,
                "price": price,
                "quantity": quantity,
                "subtotal": subtotal
            })
 
        return {
            "order_id": order_id,
            "items": bill_items,
            "total_amount": total_amount
        }
    

    def get_or_create_customer(self, customer_name: str):
    # check if exists
        stmt = select(Customer).where(
            func.lower(Customer.customer_name) == customer_name.lower()
        )
        customer = self.db.execute(stmt).scalar_one_or_none()
        
        if customer:
            return {"customer_id": customer.customer_id, "name": customer.customer_name}
        
        # create new
        new_customer = Customer(customer_name=customer_name)
        self.db.add(new_customer)
        self.db.commit()
        self.db.refresh(new_customer)
        return {"customer_id": new_customer.customer_id, "name": new_customer.customer_name}
    


