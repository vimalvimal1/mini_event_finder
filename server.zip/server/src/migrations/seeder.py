# migrations/seeder.py
from sqlalchemy.orm import Session
from repositories.Database.database import Database
from repositories.schemas.schema import *
  
from sqlalchemy import select
from contextlib import contextmanager

class Seeder:
    def __init__(self):
        self.db = Database()

    @contextmanager
    def get_session(self):
        session = self.db.SessionLocal()
        try:
            yield session
            session.commit()
            print("✓ Database seeded successfully")
        except Exception as e:
            session.rollback()
            print(f"✗ Error seeding database: {e}")
            raise
        finally:
            session.close()

    def seed_data(self):
        with self.get_session() as session:
        
            customers = [
                Customer(customer_id=101, customer_name="Madhu"),
                Customer(customer_id=102, customer_name="jaya"),
                Customer(customer_id=103, customer_name="Karthika"),
                Customer(customer_id=104, customer_name="Vimal"),
                Customer(customer_id=105, customer_name="Ram"),
                Customer(customer_id=106, customer_name="Shanthi"),
                Customer(customer_id=107, customer_name="Shree"),
                Customer(customer_id=108, customer_name="Murugan"),
                Customer(customer_id=109, customer_name="Vipin"),
            ]
            for c in customers:
                session.merge(c) 

          
            menus = [
                Menu(menu_item_id=201,menu_item_name="Cold Brew coffee",price=25.00),
                Menu(menu_item_id=202,menu_item_name="Cappuccino coffee",price=50.00),
                Menu(menu_item_id=203,menu_item_name="Espresso coffee",price=80.00),
                Menu(menu_item_id=204,menu_item_name="Masala chai",price=25.00),
                Menu(menu_item_id=205,menu_item_name="Filter coffee",price=25.00),
                Menu(menu_item_id=206,menu_item_name="Tea",price=25.00),
                Menu(menu_item_id=207,menu_item_name="Green tea",price=25.00),
                Menu(menu_item_id=208,menu_item_name="Fresh Lime Soda ",price=25.00)
                
            ]
            for m in menus:
                session.merge(m)

            inventory = [
                Inventory(item_id=301, menu_item_id=201, item_quantity=30),
                Inventory(item_id=302, menu_item_id=202, item_quantity=30),
                Inventory(item_id=303, menu_item_id=203, item_quantity=30),
                Inventory(item_id=304, menu_item_id=204, item_quantity=30),
                Inventory(item_id=305, menu_item_id=205, item_quantity=30),
                Inventory(item_id=306, menu_item_id=206, item_quantity=30),
                Inventory(item_id=307, menu_item_id=207, item_quantity=30),
                Inventory(item_id=308, menu_item_id=208, item_quantity=30)
            ]
            for i in inventory:
                session.merge(i)

            orders=[
               Order(order_id=401,customer_id=101),

            ]
            for o in orders:
                session.merge(o)
            

            order_items=[
                OrderItem(order_item_id=501, item_id=301,order_id=401, ordered_quantity=3),
                OrderItem(order_item_id=502, item_id=304,order_id=401, ordered_quantity=3),


            ]
            for o in order_items:
                session.merge(o)