from pydantic import BaseModel

from typing import Optional
class RequestDTO(BaseModel):
    customer_name:str
    query:str