from langgraph.prebuilt import create_react_agent
from langchain_aws import ChatBedrock
from langchain_mcp_adapters.client import MultiServerMCPClient
import boto3
import os
from dotenv import load_dotenv
from config.config import *
from contextlib import asynccontextmanager

load_dotenv()

def get_bedrock_client():
    return boto3.client(
        region_name=os.getenv("AWS_REGION"),
        aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
        service_name="bedrock-runtime",
    )

def get_llm(max_tokens=500, temperature=0.7):
    return ChatBedrock(
        client=get_bedrock_client(),
        model="arn:aws:bedrock:us-east-1:451433485314:application-inference-profile/eyhgqon7j4gk",
        provider="amazon",
        model_kwargs={
            "max_tokens": max_tokens,
            "temperature": temperature,
        },
    )

SYSTEM_PROMPT = """You are Brew Buddy which is a coffee shop, a cheerful coffee shop assistant.
 
Rules:

Always call get_or_create_customer first using the customer_name from the message and add the customer to the database
use the returned customer_id for all subsequent tool calls like place_order
Address and interact with the customer with their name in every response
Always have a greetings and happy texts to make the customer feel good
 Always use the tools to get real data. Never make up menu items, prices or order details.
 When a customer asks about their order, use check_order_tool with their order id.
 When a customer asks about the menu, use check_menu_tool.
 When a customer wants to place an order, use place_order_tool with their name, item and quantity.
When a customer needs to generate a bill do use the generate_bill tool and get their calculated bill accordingly
 Be warm, friendly and fun. Use emojis occasionally. Keep replies short and sweet.
 if there is new line /n..go to new line do not show "/n"
 Never show your thinking process. Only reply with the final answer.
 do not expose the thinking process you should send only the final response 
 Do NOT reveal chain-of-thought, analysis, or internal tool reasoning. 
Only return the final answer for the user. 
when the user places an order always use the customer_id provided and add to the orders table according to the tool function


- Always end with a warm closing message

"""

llm = get_llm(max_tokens=500, temperature=0)


async def get_agent():
    """Connects to MCP server and returns agent with tools"""
    client=MultiServerMCPClient({
        "brew_buddy_tools": {
            "url"      : os.getenv("MCP_SERVER_URL", "http://localhost:8000/mcp"),
            "transport": "streamable_http"
        }
    })
    tools = await client.get_tools()

    agent = create_react_agent(
            model=llm,
            tools=tools,                
            prompt=SYSTEM_PROMPT,
        )

    return agent   
