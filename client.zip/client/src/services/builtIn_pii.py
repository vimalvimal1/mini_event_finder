"""
pii_strategies_demo.py — PII Detection: All 4 Strategies Explained
====================================================================
Runs entirely with the langchain library — no AWS credentials needed.
Uses the internal _redaction helpers directly so you can see exactly
what each strategy does to a piece of text, step by step.

Run:
    python pii_strategies_demo.py

Built-in PII types supported by langchain out of the box:
  email, credit_card, ip, mac_address, url

Custom types are also supported via your own regex (shown below).
"""

import re
from langchain.agents.middleware._redaction import (
    apply_strategy,
    PIIDetectionError,
    detect_email,
    detect_credit_card,
    detect_ip,
    detect_mac_address,
    detect_url,
)

class pii:
    
    def all_matches(query):
        try:
           match=detect_email(query)
           masked=apply_strategy(query, match, "mask")
           print(masked)
        except PIIDetectionError as e:
            print(f"  Caught PIIDetectionError: {e}")
            
            print("""
  How it works:
    Raises immediately — apply_strategy never returns.
    No sanitised text exists. The agent never runs.
    The caller (your application) decides what to do next.

  What your app should do when catching this:
    1. Log the detection event (WITHOUT the PII value itself).
    2. Return a safe message to the user:
       "We detected a sensitive value in your request.
        Please remove it and try again."
    3. Optionally alert a security team.

  Use when:
    • API keys, passwords, SSNs — values that must NEVER enter
      the LLM pipeline under any circumstances.
    • Compliance rules that require hard rejection (not sanitisation).
    • You want the human to fix their input, not silently strip it.
""")
            
        

    

