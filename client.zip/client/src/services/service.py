from repositories.repo import OrderRepository
from agents.agent import get_agent
from utilities.exceptions.custom_execption import CustomAppException
from utilities.constants.error_codes import ErrorCode
from utilities.constants.http_status import HttpStatusCode
from langchain_core.runnables import RunnableConfig


class OrderService:

    def __init__(self, repo: OrderRepository):
        self.repo = repo

    async def process_service(self, customer_name, query):
        try:
            context = f"[customer_name:{customer_name}]{query}"
            agent = await get_agent(query)

            config = RunnableConfig(configurable={"thread_id": customer_name})

            result = await agent.ainvoke(         
            {"messages": [("user", context)]},
            config
        )

            if "messages" in result:
                return result["messages"][-1].content

            return result

        except CustomAppException:
            raise

        except Exception as e:
            error_msg=str(e)
            self.repo.log_error(
            file_name="service.py",
            function_name="process_service",
            error_message=error_msg
        )
        raise CustomAppException(
            message=f"Service layer error: {error_msg}",
            code=ErrorCode.INTERNAL_SERVER_ERROR,
            status_code=HttpStatusCode.INTERNAL_SERVER_ERROR
        )