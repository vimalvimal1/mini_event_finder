from repositories.repo import OrderRepository
from agents.agent import get_agent
from utilities.exceptions.custom_execption import CustomAppException
from utilities.constants.error_codes import ErrorCode
from utilities.constants.http_status import HttpStatusCode
from services.builtIn_pii import pii



class OrderService:

    def __init__(self, repo: OrderRepository):
        self.repo = repo

    async def process_service(self, customer_name, query):
        try:
            context = f"[customer_name:{customer_name}]{query}"
            check=pii.all_matches(query)
            if check!=None:
                return check           
            agent=await get_agent()

            result=await agent.ainvoke({
                "messages":[("user", context)]
            })

            if "messages" in result:
                return result["messages"][-1].content

            return result

        except CustomAppException:
            raise
        
        

        except Exception as e:
            self.repo.log_error(
                file_name="service.py",
                function_name="process_service",
                error_message=str(e)
            )
            raise CustomAppException(
                message=f"Service layer error: {str(e)}",
                code=ErrorCode.INTERNAL_SERVER_ERROR,
                status_code=HttpStatusCode.INTERNAL_SERVER_ERROR
            )