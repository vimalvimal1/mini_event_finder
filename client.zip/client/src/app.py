from contextlib import asynccontextmanager
from fastapi import FastAPI
import uvicorn
from routers.router import router
from migrations.migration import Migration

from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from models.api_response_dto import APIResponse, Error
from utilities.exceptions.custom_execption import CustomAppException
from utilities.constants.error_codes import ErrorCode, ErrorCodeStatus
from utilities.constants.http_status import HttpStatusCode


app = FastAPI(
    title="Order Management API",
    description="REST API for internal careeer and skill management process",
    version="1.0.0",    
)

app.include_router(router)


@app.on_event("startup")
async def startup_event():
    """Run migrations and seed data on application startup"""
    migration = Migration()
    migration.run_startup_migration()
   


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)


@app.exception_handler(CustomAppException)
async def custom_exception_handler(request: Request, exc: CustomAppException):
    api_response = exc.to_api_response()
    return JSONResponse(
        status_code=exc.status_code,
        content=api_response.to_dict()
    )

@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    errors = []
    for error in exc.errors():
        errors.append(Error(
            code=ErrorCode.VALIDATION_ERROR,
            message=f"{error['loc'][-1]}: {error['msg']}",
            
        ))
    
    api_response = APIResponse(
        data=None,
        errors=errors,
        code=HttpStatusCode.UNPROCESSABLE_ENTITY
    )
    
    return JSONResponse(
        status_code=HttpStatusCode.UNPROCESSABLE_ENTITY,
        content=api_response.to_dict()
    )
    
if __name__ == "__main__":
    
    uvicorn.run(
        "app:app",
        host="0.0.0.0",
        port=8080,
        reload=True,
        log_level="info"
    )