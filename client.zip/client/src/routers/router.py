from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from services.service import OrderService
from models.model import RequestDTO
from Database.database import Database, db_provider
from sqlalchemy.orm import Session
from repositories.repo import OrderRepository
from models.api_response_dto import APIResponse
from utilities.constants.http_status import HttpStatusCode
from utilities.exceptions.custom_execption import CustomAppException
from utilities.constants.error_codes import ErrorCode

router=APIRouter(prefix="/api/v1")
db_provider = Database() 

def get_repo(db: Session = Depends(db_provider.get_session)):
    return OrderRepository(db)

def get_service(repo:OrderRepository=Depends(get_repo)):
    return OrderService(repo)

@router.post("/chat/pii")

async def process(request: RequestDTO, service: OrderService=Depends(get_service), repo:OrderRepository=Depends(get_repo)):
    try:
        response=await service.process_service(
            customer_name=request.customer_name,
            query=request.query
        )

        return response
    
    except Exception as e:
        repo.log_error(file_name="router.py",function_name="process()", error_message=str(e))
        
        raise CustomAppException(
            message=f"Router error : {str(e)}",
            code=ErrorCode.INTERNAL_SERVER_ERROR,
            status_code=HttpStatusCode.INTERNAL_SERVER_ERROR,
        )


@router.get("/error-logs")
async def get_error_logs(repo: OrderRepository = Depends(get_repo)):
    try:
        logs = repo.get_all_error_logs()
        return APIResponse(
            data    = logs,
            code    = HttpStatusCode.OK,
            message = "Error logs fetched successfully"
        )

    except CustomAppException:
        raise

    except Exception as e:
        raise CustomAppException(
            message     = f"Router error: {str(e)}",
            code        = ErrorCode.INTERNAL_SERVER_ERROR,
            status_code = HttpStatusCode.INTERNAL_SERVER_ERROR
        )


